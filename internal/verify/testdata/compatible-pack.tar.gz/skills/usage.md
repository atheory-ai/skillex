---
name: Signed example guidance
description: Verified registry guidance for Go repositories.
topics: [verified-example]
tags: [fixture]
---

# Signed example guidance

Use this verified guidance in Go projects.
